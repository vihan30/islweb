<?php  
include 'connect.php';
$msg = "";
if (isset($_POST['btn'])){ 
							// name of the uploaded file
                             $filename = $_FILES['fileToUpload']['name'];

                           // destination of the file on the server
                           $destination = 'Database/' . $filename;

                           // get the file extension
                            $extension = pathinfo($filename, PATHINFO_EXTENSION);

                             // the physical file on a temporary uploads directory on the server
                            $file = $_FILES['fileToUpload']['tmp_name'];
                            $size = $_FILES['fileToUpload']['size'];

    if (!in_array($extension, ['zip', 'pdf', 'docx','png','jpg','png'])) {
        echo "You file extension must be .zip, .pdf or .docx or .png or .jpg";
          } 
          else {
           // move the uploaded (temporary) file to the specified destination
             if (move_uploaded_file($file, $destination)) {
             $sql = "INSERT INTO data_base (admin_id, d_base ,size,permission) VALUES ('1','$filename', $size,'0')";
            if (mysqli_query($db, $sql)) {
                echo "<script>
                 alert('File uploaded');
                  window.location.href='http://localhost/isl/admin/database.php';
              </script";
                                          }
                                                           } 
                                                           else 
                                                           {
                                                             echo "Failed to upload file.";
                                                            }
               }
                        }         
                          
if (isset($_POST['public']))
{
   $id = mysqli_real_escape_string($db, $_POST['id']);
   $query = "UPDATE data_base SET permission = '2' WHERE d_id='$id'";
   $submit=mysqli_query($db, $query);
   if($submit){
                    
                              echo "<script>
                 alert('Now Database is accessible to everyone');
                  window.location.href='http://localhost/isl/admin/database.php';
              </script>"; 
                                         }
}
if (isset($_POST['private']))
{
   $id = mysqli_real_escape_string($db, $_POST['id']);
   $query = "UPDATE data_base SET permission = '1' WHERE d_id='$id'";
   $submit=mysqli_query($db, $query);
   if($submit){
                    
                              echo "<script>
                 alert('Now Database is private only selected user can access');
                  window.location.href='http://localhost/isl/admin/database.php';
              </script>"; 
                                         }
}        
if (isset($_POST['hide']))
{
   $id = mysqli_real_escape_string($db, $_POST['id']);
   $query = "UPDATE data_base SET permission = '0' WHERE d_id='$id'";
   $submit=mysqli_query($db, $query);
   if($submit){
                    
                              echo "<script>
                 alert('Now Database is hidden from everyone');
                  window.location.href='http://localhost/isl/admin/database.php';
              </script>"; 
                                         }
} 
if (isset($_POST['delete_data']))
{
   $id = mysqli_real_escape_string($db, $_POST['id']);
   $sql = "SELECT * FROM data_base WHERE d_id=$id";
   $result = mysqli_query($db, $sql);
   $r= mysqli_fetch_array($result);
   $filename = $r['d_base'];
   unlink("Database/".$filename);
   $query = "DELETE FROM data_base WHERE d_id='$id'";
   $submit=mysqli_query($db, $query);
   if($submit){
                    
                              echo "<script>
                 alert('Database Deleted');
                  window.location.href='http://localhost/isl/admin/database.php';
              </script>"; 
                                         }
}        
if (isset($_POST['download']))
{
   $id = mysqli_real_escape_string($db, $_POST['id']);

    // fetch file to download from database
    $sql = "SELECT * FROM data_base WHERE d_id=$id";
    $result = mysqli_query($db, $sql);

    $file = mysqli_fetch_assoc($result);
    $filepath = 'Database/' . $file['d_base'];

    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream/image/jpg');
        header('Content-Disposition: attachment; filename=' . basename($filepath));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize('Database/' . $file['d_base']));
        readfile('Database/' . $file['d_base']);

        ob_clean(); // buffer clean
        
        exit;
    }

}                                                                                 
?>  