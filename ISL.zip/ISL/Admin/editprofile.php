<?php require 'server.php'; ?>
<?php include 'edit_profile_server.php' ; ?>
<?php
 if (!isset($_SESSION["name"])){
    $_SESSION['msg'] = "You must log in first";
    header('location: ad-login.php');
  }
  if(isset($_SESSION["name"])){
    //display
    $query = "SELECT * FROM admin where Phone ='".$_SESSION['name']."'"; 
    $result_1 = mysqli_query($db, $query); 
    $res_1 = mysqli_fetch_array($result_1);
  }
  ?>
<!DOCTYPE html>
<html>
<head>
  <script type="text/javascript" src="script.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <link rel="stylesheet" type="text/css" href="editprofile.css">
  <title></title>
</head>
<body>
  <?php include 'adminheader.php';  ?>
      <div class="container" id="editprofile">
    <div class="row">
        <div class="card" >
          <div class="card-body">
            <div class="e-profile">
            <?php 
            include('errors.php'); 
            echo $msg;
            ?>
            <form action="editprofile.php" method="Post" enctype="multipart/form-data">
              <div class="row">
                <div>
                      <span class="img-div">
                        <div class="text-center img-placeholder"  onClick="triggerClick()">
                            <h4>Update image</h4>
                        </div>
                        <img src="<?php echo $res_1["image"]; ?>" onClick="triggerClick()" id="profileDisplay">
                      </span>
                      <input type="file" name="profileImage" onChange="displayImage(this)" id="profileImage" class="form-control" style="display: none;">
                </div>
              </div>
              <div style="margin-top: 5%">
              <ul class="nav nav-tabs">
                <li class="nav-item"><a href="" class="active nav-link display-4">Edit Profile</a></li>
              </ul>
              <div class="tab-content pt-3">
                <div class="tab-pane active">
                    <div class="row">
                      <div class="col">
                        <div class="row">
                          <div class="col">
                            <div class="form-group">
                              <label>Full Name</label>
                              <input class="form-control" type="text" name="name" value="<?php echo $res_1['name']; ?> ">
                            </div>
                            <div class="form-group">
                              <label>Mobile no.</label>
                              <input class="form-control" type="text" name="mobile" placeholder="10 digit mobile no." value="<?php echo $res_1['Phone']; ?>">
                            </div>
                            <div class="form-group">
                              <label>Works at</label>
                              <input class="form-control" type="text" name="work" placeholder="Post and organization" value="<?php echo $res_1['working']; ?>">
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col">
                            <div class="form-group">
                              <label>Email</label>
                              <input class="form-control" type="text" placeholder="user@example.com"  name="email" value="<?php echo $res_1['email']; ?>">
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col mb-3">
                            <div class="form-group">
                              <label>About</label>
                              <textarea class="form-control" rows="5" placeholder="My Bio" name="bio" ><?php echo $res_1['Bio']; ?></textarea>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col d-flex justify-content-end adminEditProfile">
                        <button class="btn btn-primary " type="submit" name="save_profile">Save Changes</button>
                      </div>
                    </div>
                  </form>

                </div>
              </div>  
              </div>
            </div>
          </div>
      

</body>
</html>

