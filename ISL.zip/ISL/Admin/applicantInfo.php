<?php
include 'server.php';
if (!isset($_SESSION["name"])){
    $_SESSION['msg'] = "You must log in first";
    header('location: ad-login.php');
}
include 'dataApplication_server.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>    
    <link rel="stylesheet" href="applicantInfo.css">
    <title>Document</title>
</head>
<body>
    <div>
        <?php include 'dataApplication.php';?>
    </div>
    <div class="bg-modal container-fluid" id="applicantInfo">
        <div class="modal-content">
            <form action="applicantInfo.php" method="post">
                <div class="close" style="font-size:3rem;"><a href="dataApplication.php#pending_application">+</a></div>
                <h3 class="display-4">Details</h3>
                <div class="applicantData">
                    <?php 
                    $id = $_GET['id'];
                    $query = "SELECT * FROM db_user where id='$id'"; 
                    $result = mysqli_query($db, $query);
                    $res = mysqli_fetch_array($result);
                    echo "<input type='hidden' value='$id' style='border:none; width: auto;' name='id' readonly><br>";
                    echo "Name: ".$res['name']."<br>";
                    echo "Currently working as: ".$res['bio']."<br>";
                    echo "Purpose<br>".$res['purpose']."<br>";
                    ?><br>
                    <?php
                    if ($res['permission']==0) {
                        echo"
                    <button class='btn btn-success popUpFormButton' name='btn'>Grant</button>
                    <button class='btn btn-danger' name='btn_1'>Reject</button>";
                    }
                    if ($res['permission']==1) {
                        echo"
                    <button class='btn btn-success popUpFormButton' name='btn_2'>Revoke</button>
                    <button class='btn btn-danger' name='btn_1'>Reject</button>";
                    }
                    if ($res['permission']==2) {
                        echo"
                    <button class='btn btn-success popUpFormButton' name='btn'>Grant</button>
                    <button class='btn btn-danger' name='btn_3'>Delete</button>";
                    }
                    
                    ?>
                </div>
            </form>
        </div>
    </div>
</body>
</html>