<?php
include 'connect.php'; 
//Grant permission
if (isset($_POST['btn']))
{
 $id = mysqli_real_escape_string($db, $_POST['id']);
 $query = "UPDATE db_user SET permission = '1' WHERE id='$id'";
 $submit=mysqli_query($db, $query);
 if($submit){
   $query = "SELECT * FROM db_user WHERE id='$id'"; 
   $result = mysqli_query($db, $query); 
   $r = mysqli_fetch_assoc($result);
   $username = $r['user_id'];
   $query_2 = "SELECT * FROM users WHERE username='$username'"; 
   $result_2 = mysqli_query($db, $query_2);
   $r_2 = mysqli_fetch_assoc($result_2);
   $email = $r_2['email']; 
   $to = $email;
   $subject = "ISL dataApplication";

   $message = "Dear ".$username." Your Data Application is Accepted";
   $headers =  'MIME-Version: 1.0' . "\r\n"; 
   $headers .= "From: mailserver3011@gmail.com . \r\n";
   $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
   mail($to, $subject, $message, $headers);
   echo "<script>
   alert('Permission Granted');
   window.location.href='http://localhost/isl/admin/dataApplication.php#pending_application';
   </script>"; 
 }
}
//reject permission
if (isset($_POST['btn_1']))
{
 $id = mysqli_real_escape_string($db, $_POST['id']);
 $query = "UPDATE db_user SET permission = '2' WHERE id='$id'";
 $submit=mysqli_query($db, $query);
 if($submit){

  echo "<script>
  alert('Application Rejected');
  window.location.href='http://localhost/isl/admin/dataApplication.php#pending_application';
  </script>"; 
}
}
//revoke permission...
if (isset($_POST['btn_2']))
{
 $id = mysqli_real_escape_string($db, $_POST['id']);
 $query = "UPDATE db_user SET permission = '0' WHERE id='$id'";
 $submit=mysqli_query($db, $query);
 if($submit){

  echo "<script>
  alert('Permission Revoked');
  window.location.href='http://localhost/isl/admin/accepted_application.php';
  </script>"; 
}
}
//delete record
if (isset($_POST['btn_3']))
{
   $id = mysqli_real_escape_string($db, $_POST['id']);
   $query = "DELETE FROM db_user WHERE id='$id'";
   $submit=mysqli_query($db, $query);
   if($submit){
                    
                              echo "<script>
                 alert('Application Deleted');
                  window.location.href='http://localhost/isl/admin/rejected_application.php';
              </script>"; 
                                         }
}
?> 
