<?php include 'connect.php';  
include 'server.php';
if (!isset($_SESSION["name"])){
    $_SESSION['msg'] = "You must log in first";
    header('location: ad-login.php');
  }
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php include 'adminheader.php';  ?>	
<div id="users_table">
<?php 
echo "<table class='table'>
<thead>
<tr>
<th>Username</th>
<th>Email Id</th>
</tr>
</thead>";
$query = "SELECT * FROM users"; 
$result = mysqli_query($db, $query); 

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['username'] . "</td>";
echo "<td>" . $row['email'] . "</td>";
echo "</tr>";
}
echo "</table>";
 ?>
</div>
</body>
</html>