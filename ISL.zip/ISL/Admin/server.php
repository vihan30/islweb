<?php

include 'connect.php';
  
   //usertable count

   $query = "SELECT * FROM users"; 
    $result = mysqli_query($db, $query); 
      
    if ($result) 
    { 
        // it return number of rows in the table. 
        $total_1 = mysqli_num_rows($result); 
     }

    //Data Application count 
    $query = "SELECT * FROM db_user WHERE permission='0'"; 
    $result = mysqli_query($db, $query); 
      
    if ($result) 
    { 
        // it return number of rows in the table. 
        $total_2 = mysqli_num_rows($result); 
     }
     // Application accepted count
  	$query = "SELECT * FROM db_user where permission = '1'"; 
    $result = mysqli_query($db, $query); 
      
    if ($result) 
    { 
        // it return number of rows in the table. 
        $total_3 = mysqli_num_rows($result); 
     }   
     $query = "SELECT * FROM db_user WHERE permission = '2'"; 
    $result = mysqli_query($db, $query); 
      
    if ($result) 
    { 
        // it return number of rows in the table. 
        $total_4 = mysqli_num_rows($result); 
     }
?>


<?php
//admin_Login
if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

$mobile = "";
$email    = "";
$name  ="";
$errors = array(); 

// LOGIN Admin
if (isset($_POST['login_user'])) {
  $mobile = mysqli_real_escape_string($db, $_POST['mobile']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($mobile)) {
    array_push($errors, "Mobile no. is required");
  }
  if (empty($password)) {
    array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
    $password = md5($password);
    $query = "SELECT * FROM admin WHERE Phone='$mobile' AND Pswrd='$password'";
    $results = mysqli_query($db, $query) or die ("Error");
    if (mysqli_num_rows($results) == 1) {

      $_SESSION['name'] = $mobile;
      $_SESSION['success'] = "You are now logged in";
      header('location:http://localhost/isl/admin/admin.php');
    }else {
        array_push($errors, "Wrong Mobile no./password combination");
    }
  }
}

?>



