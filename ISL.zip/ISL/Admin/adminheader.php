<?php include 'server.php'; ?>
<?php
if (!isset($_SESSION['name'])) {
	$_SESSION['msg'] = "You must log in first";
	header('location: ad-login.php');
}
if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['name']);
	header("location: ad-login.php");
}
$query = "SELECT * FROM admin"; 
$result = mysqli_query($db, $query); 
$res = mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="admin2.css">
	<title>ISL Admin</title>
</head>
<body>


	<div class="jumbotron">
		<?php if (isset($_SESSION['name'])) : ?>
			<div class="adminLogoutButton float-right btn btn-danger">
				<a href="adminheader.php?logout='1'"><span><b>Log out</b></span></a>
			</div>
			<div class="adminImage">
				<img src="<?php echo $res["image"]; ?>" alt="Admin Photo" style=" height: 250px ; width: 250px ;">
			</div>
			<p class="lead"><?php echo $res['name']; ?> <br>
				<?php echo $res['working']; ?> <br>
				<?php echo $res['email']; ?> <br>
				<?php echo $res['Phone']; ?> <br>
			</p>

		<?php endif ?>
	</div>
	<ul class="nav justify-content-center">
		<li class="nav-item">
			<a class="nav-link" href="editprofile.php#editprofile">Edit Profile</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="changepassword.php#changePassword">Change Password</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="database.php#database">Database</a>
		</li>
	</ul>


	<div class="adminRowData">
		<div class="container">

			<div class="row">
				<div class="card col-sm-6 ">
					<a href="users.php#users_table"><div class="card-body">
						<div class="card-title"><?php
						echo $total_1;   
						?></div>
						<div class="card-text">Total Number Of Registered Users</div>
					</div></a>
				</div>

				<div class="card col-sm-6" style="width: 18rem">
					<a href="dataApplication.php#pending_application"><div class="card-body">
						<div class="card-title"><?php
						echo $total_2;   
						?></div>
						<div class="card-text">Pending Data Applications</div>
					</div>
				</a>
			</div>

			<div class="card col-sm-6 adminRowData"  style="width: 18rem">
				<a href="accepted_application.php#accepted_application_table"><div class="card-body">
					<div class="card-title"><?php
					echo $total_3;   
					?></div>
					<div class="card-text">Total Number Of Applications Accepted</div>
				</div>
			</a>
		</div>


		<div class="card col-sm-6 adminRowData" style="width: 18rem">
			<a href="rejected_application.php#rejected_application"><div class="card-body">
				<div class="card-title"><?php
				echo $total_4;   
				?></div>
				<div class="card-text">Total Number Of Applications Rejected</div>
			</div>
		    </a>
	    </div>
</div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script src="applicantInfo.js"></script>
<script
src="https://code.jquery.com/jquery-3.4.1.js"
integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
crossorigin="anonymous"></script>
</body>
</html>