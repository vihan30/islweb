
<?php require('connect.php') ?>
 <?php


 $errors = array();
    // taking inputs
           if (isset($_POST['reset_pass'])) {
  $mobile = mysqli_real_escape_string($db, $_POST['phone']);
  $password1 = mysqli_real_escape_string($db, $_POST['new_password']);
  $password2= mysqli_real_escape_string($db, $_POST['confirm_password']);
  $otp= mysqli_real_escape_string($db,$_POST['OTP']);
  $errors = array(); 
   if (empty($mobile)) {
    array_push($errors, "Mobile no. is required");
  }
  if (empty($password1)) {
    array_push($errors, "Password is required");
  }
  if (empty($password2)) {
    array_push($errors, "confirmation of password is required");
  }
   if (empty($otp)) {
    array_push($errors, "OTP is required");
  }
   if ($password1 != $password2) {
  array_push($errors, "The two passwords do not match");
  }
  //calculating username
  $query = "SELECT * FROM admin WHERE Phone='$mobile'";
    $results = mysqli_query($db, $query);
    $res = mysqli_fetch_assoc($results);
    $username = $res['id'];

  if (count($errors) == 0) {
    //checking is otp and username are correct
    
    $token_hash = md5($otp);
    $query = "SELECT * FROM admin_recovery_key WHERE userID='$username' AND token='$token_hash'";
    $results = mysqli_query($db, $query);
    $res_1 = mysqli_fetch_assoc($results);
    if ($res_1){
      $time_1 = $res_1['created'];
      $tym = strtotime($time_1) ;
      $time_2 = strtotime(date('Y-m-d H:i:s',time()));
       $diff = $time_2 - $tym;  
       $diff2 = (($diff)/60) ;
       //checking life of otp
       if ($diff2 < 5) {
        $password = md5($password1);
        //updating password
        $query = "UPDATE admin SET Pswrd= '$password' WHERE id='$username'";
         $submit=mysqli_query($db, $query);
                             if($submit){
                              echo "<script>
                 alert('Your Password has been changed successfully.Please Login');
                  window.location.href='http://localhost/isl/admin/ad-login.php';
              </script>"; 
                                         }
                       }
       else {
         echo "<script>
                 alert('Your OTP has been expired please generate a new one');
                  window.location.href='forgot_admin_password.php';
              </script>";                     
            }         
                }  
                else {
               array_push($errors, "Wrong credentials combination");
                }

                          }


                                            }

?>