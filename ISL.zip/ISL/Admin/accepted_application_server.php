<?php
include 'connect.php'; 
if (isset($_POST['btn']))
{
   $id = mysqli_real_escape_string($db, $_POST['id']);
   $query = "UPDATE db_user SET permission = '0' WHERE id='$id'";
   $submit=mysqli_query($db, $query);
   if($submit){
                    
                              echo "<script>
                 alert('Permission Revoked');
                  window.location.href='http://localhost/isl/admin/accepted_application.php';
              </script>"; 
                                         }
}
if (isset($_POST['btn_1']))
{
   $id = mysqli_real_escape_string($db, $_POST['id']);
   $query = "UPDATE db_user SET permission = '2' WHERE id='$id'";
   $submit=mysqli_query($db, $query);
   if($submit){
                    
                              echo "<script>
                 alert('Application Rejected');
                  window.location.href='http://localhost/isl/admin/accepted_application.php';
              </script>"; 
                                         }
}
?> 
