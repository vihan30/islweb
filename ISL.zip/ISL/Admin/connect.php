<?php

$db = mysqli_connect('localhost', 'root', '', 'isl');
if (!$db){
    die("Database Connection Failed" . mysqli_error($db));
}

?>