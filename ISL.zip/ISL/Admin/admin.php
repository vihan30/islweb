<?php 
include 'connect.php'; 
include 'server.php';
if (!isset($_SESSION["name"])){
    $_SESSION['msg'] = "You must log in first";
    header('location: ad-login.php');
  }
$query = "SELECT * FROM admin"; 
$result = mysqli_query($db, $query); 
$res = mysqli_fetch_array($result);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">    
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<title></title>
</head>
<body>
<?php include 'adminheader.php';  ?>	
<div>	
	<div id="lower-section" style="margin-left: 5%;margin-right: 5%;">
		     <h3 class="display-3">More about the Admin</h3>
			<p class="fluid-container"> <?php echo $res['Bio']; ?> </p>
	</div>
</div>
</body>
</html>