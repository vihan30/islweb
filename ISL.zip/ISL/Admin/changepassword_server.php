<?php
       include 'connect.php';
       $msg = "";
       $errors = array(); 
       if (isset($_POST['save_profile'])) {
         $pswrd1 = mysqli_real_escape_string($db, $_POST['c_pswrd']);
         $pswrd2 = mysqli_real_escape_string($db, $_POST['n_pswrd']);
         $pswrd3 = mysqli_real_escape_string($db, $_POST['n_confirm_pswrd']);
       //pswrd change
        $pswrd4 = md5($pswrd1);
        $query_1 = "SELECT * FROM admin where id=1"; 
        $result_2 = mysqli_query($db, $query_1); 
        $res_2 = mysqli_fetch_array($result_2);
        $pswrd5 = $res_2['Pswrd'];
    
         if (empty($pswrd1)) {
            array_push($errors, "Original password is required to change password .If you don't want to change password Please keep all password fields empty!!");
                            }
         if (empty($pswrd2)) {
            array_push($errors, "Please set new  password.If you don't want to change password Please keep all password fields empty!!");
                            }
         if (empty($pswrd3)) { array_push($errors, "Please confirm password.!!"); }
         if ($pswrd2 != $pswrd3) {
                              array_push($errors, "The two passwords do not match");
                                }                    
         if ($pswrd4 != $pswrd5) {
                              array_push($errors, "The current password you entered doesn't match");
                                }    
         if (count($errors) == 0) {
      
              $pswrd6=md5($pswrd2);
              $sql = "UPDATE admin SET Pswrd='$pswrd6' WHERE id = 1";
              mysqli_query($db, $sql) or die(mysqli_error($db));
            if(mysqli_query($db, $sql)){
              $msg = "Data uploaded and saved in the Database";
              header('refresh:5;http://localhost/isl/admin/ad-login.php');
                                    }
                                     else {
              $msg = "There was an error in the database";
                                           }

                              }
    }
?>