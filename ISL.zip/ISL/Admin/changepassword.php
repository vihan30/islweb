<?php require 'server.php'; ?>
<?php include 'changepassword_server.php' ; ?>
<?php
if (!isset($_SESSION["name"])){
  $_SESSION['msg'] = "You must log in first";
  header('location: ad-login.php');
}
if(isset($_SESSION["name"])){
    //display
  $query = "SELECT * FROM admin where Phone ='".$_SESSION['name']."'"; 
  $result_1 = mysqli_query($db, $query); 
  $res_1 = mysqli_fetch_array($result_1);
}
?>

<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="changePassword.css">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <title>Change Password</title>
</head>
<body>
 <?php include 'adminheader.php';  ?>
 <div class="container" id="changePassword">
  <div class="col">
    <div class="row">
      <div class="col mb-3">
        <div class="card" style="margin:2% 10% 10% ">
          <div class="card-body">
            <div class="e-profile">
              <?php 
              include('errors.php'); 
              echo $msg;
              ?>
              <form action="changepassword_server.php" method="Post">
                <div class="row">
                  <div class="col-12 col-sm-6 mb-3">
                    <div class="mb-2"><h2 class="display-4" style="font-size: 3rem;">Change Password</h2></div>
                    <div class="row">
                      <div class="col">
                        <div class="form-group">
                          <label>Current Password</label>
                          <input class="form-control" type="password" name="c_pswrd" placeholder="••••••">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col">
                        <div class="form-group">
                          <label>New Password</label>
                          <input class="form-control" type="password" name="n_pswrd" placeholder="••••••">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col">
                        <div class="form-group">
                          <label>Confirm <span class="d-none d-xl-inline">Password</span></label>
                          <input class="form-control" type="password" name="n_confirm_pswrd" placeholder="••••••"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col d-flex justify-content-end changePasswordAdmin">
                      <button class="btn btn-primary " type="submit" name="save_profile">Save Changes</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>            
</body>
</html>