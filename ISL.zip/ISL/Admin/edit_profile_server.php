
<?php
  //edit profile..
  include 'connect.php';
  $msg = "";
  if (isset($_POST['save_profile'])) {
    // for the database
    $name = mysqli_real_escape_string($db, $_POST['name']);
    $mobile = mysqli_real_escape_string($db, $_POST['mobile']);
    $working = mysqli_real_escape_string($db, $_POST['work']);
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $bio = mysqli_real_escape_string($db, $_POST['bio']);
    $profileImageName =$_FILES["profileImage"]["name"];  
    $errors = array(); 
  
    

    // For image upload
    $target_dir = "img/";
    $target_file = $target_dir . basename($_FILES["profileImage"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    // VALIDATION
    // validate image size. Size is calculated in Bytes
  
    //other data
    if (empty($name)) { 
      array_push($errors,"Name can't be empty");
                           }
    if (empty($mobile)) { 
          array_push($errors,"Please fill mobile no.");
                      }
    if (empty($working)) { 
          array_push($errors,"Please fill Works at");
                      }
    if (empty($email)) { 
          array_push($errors,"Please fill Email");
                      }              
    if (empty($bio)) { 
          array_push($errors,"Please fill Bio");    
                      }                      
    
    // Upload data only if no errors                            

    if (count($errors) == 0 ){
      
      if(move_uploaded_file($_FILES["profileImage"]["tmp_name"], $target_file)) {
          $sql = "UPDATE admin SET image='$target_file',name='$name', email='$email',Phone='$mobile',working='$working', Bio='$bio'WHERE id = 1";
        if(mysqli_query($db, $sql)){
          $msg = "Data uploaded and saved in the Database";
          header('refresh:5;admin.php');
          ;
                                    } else {
          $msg = "There was an error in the database";
                                           }
      } else {
              $sql = "UPDATE admin SET name='$name', email='$email',Phone='$mobile',working='$working', Bio='$bio'WHERE id = 1";
        if(mysqli_query($db, $sql)){
          $msg = "Data uploaded and saved in the Database";
          header('refresh:5;admin.php');
          ;
                                    } else {
          $msg = "There was an error in the database";
                                           }
             }
                                                                                 }
                         }
                        

?>