<?php 
include 'connect.php'; 
include 'server.php';
include 'database_server.php';
if (!isset($_SESSION["name"])){
    $_SESSION['msg'] = "You must log in first";
    header('location: ad-login.php');
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Database</title>
</head>
<body>
<?php include 'adminheader.php'; ?>
<div id="database">	
	<h2>Available Files</h2>

	<h3>Public</h3>
<?php 
echo "<table>
<tr>
<th>Database Id</th>
<th>Database</th>
<th>Options</th>
</tr>";
$query = "SELECT * FROM data_base where permission='2'"; 
$result = mysqli_query($db, $query); 

while($row = mysqli_fetch_array($result))
{
echo "<tr>
<form action='database.php' method ='POST'>
<td><input type='text' value='".$row['d_id']."' style='border:none; background-color:#f0decb; margin-left:40%;' name='id' readonly></td>
<td>".$row['d_base']."</td>
<td><button class='btn btn-primary' type='submit' name='private'>Private</button><button class='btn btn-primary' type='submit' name='hide'>Hide</button><button class='btn btn-primary' type='submit' name='delete_data'>Delete</button><button class='btn btn-primary' type='submit' name='download'>Download</button></td>
</form>
</tr>";	
}
echo "</table>";
 ?>

	<h3>Private</h3>

<?php 
echo "<table>
<tr>
<th>Database Id</th>
<th>Database</th>
<th>Options</th>
</tr>";
$query = "SELECT * FROM data_base where permission='1'"; 
$result = mysqli_query($db, $query); 

while($row = mysqli_fetch_array($result))
{
echo "<tr>
<form action='database.php' method ='POST'>
<td><input type='text' value='".$row['d_id']."' style='border:none; background-color:#f0decb; margin-left:40%;' name='id' readonly></td>
<td>".$row['d_base']."</td>
<td><button class='btn btn-primary' type='submit' name='public'>Public</button><button class='btn btn-primary' type='submit' name='hide'>Hide</button><button class='btn btn-primary' type='submit' name='delete_data'>Delete</button><button class='btn btn-primary' type='submit' name='download'>Download</button></td>
</form>
</tr>";	
}
echo "</table>";
 ?>
	<h3>Hidden</h3>

<?php 
echo "<table>
<tr>
<th>Database Id</th>
<th>Database</th>
<th>Options</th>
</tr>";
$query = "SELECT * FROM data_base where permission='0'"; 
$result = mysqli_query($db, $query); 

while($row = mysqli_fetch_array($result))	
{
echo "<tr>
<form action='database.php' method ='POST'>
<td><input type='text' value='".$row['d_id']."' style='border:none; background-color:#f0decb; margin-left:40%;' name='id' readonly></td>
<td>".$row['d_base']."</td>
<td><button class='btn btn-primary' type='submit' name='public'>Public</button><button class='btn btn-primary' type='submit' name='private'>Private</button>
<button class='btn btn-primary' type='submit' name='download'>Download</button>
<button class='btn btn-primary' type='submit' name='delete_data'>Delete</button></td>
</form>
</tr>";	
}
echo "</table>";
 ?>
	
	<h3>Upload File</h3>
<form action="database.php" method="post" enctype="multipart/form-data">  
    Select File:  
    <input type="file" name="fileToUpload"/>  
    <button class='btn btn-primary' type='submit' name='btn'>Upload File</button> 
</form>  
</div>
</body>
</html>