<?php  if (count($errors) > 0) : ?>
  <div class="error">
    <?php foreach ($errors as $error) : ?>
      <i style= "color: rgb(#FF0000);"><?php echo $error ?></i>
    <?php endforeach ?>
  </div>
<?php  endif ?>

