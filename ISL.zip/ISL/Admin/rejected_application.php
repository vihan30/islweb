<?php 
include 'connect.php'; 
include 'server.php';
if (!isset($_SESSION["name"])){
    $_SESSION['msg'] = "You must log in first";
    header('location: ad-login.php');
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php include 'adminheader.php';  ?>
<div id="rejected_application">
<?php 
echo "<table class='table container-fluid'>
<thead>
<tr>
<th>App Id</th>
<th> Name </th>
<th>Bio</th>
</tr>
</thead>";
$query = "SELECT * FROM db_user where permission='2'"; 
$result = mysqli_query($db, $query); 

while($row = mysqli_fetch_array($result))
{
echo "<tr>
<form action='rejected_application.php' method ='POST'>
<td><input type='text' value='".$row['id']."' style='border:none;' name='id' readonly></td>
<td>".$row['name']."</td>
<td>".$row['bio']."</td>
<td><a href='applicantInfo.php?id=".$row['id']."#applicantInfo'>View Details</a></td>
</form>
</tr>";
}
echo "</table>";
 ?>
</div>
</body>
</html>