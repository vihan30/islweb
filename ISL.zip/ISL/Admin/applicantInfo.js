$(".close").on("click", function() {
    $(".bg-modal").hide()
})