<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php	  
$savedTime  = strtotime('2019-11-02 08:03:24 ');
$currentTime = date('Y-m-d H:i:s',time());
$currentTime1 = strtotime($currentTime);
$differenceInSeconds = ($currentTime1 - $savedTime)/60;
echo $differenceInSeconds;
echo "<br>";
echo $currentTime;
if ($differenceInSeconds < 5){
	echo "yehh";
}
?>
 <video width="320" height="240" autoplay>
  <source src="Batman Begins.mp4" type="video/mp4">
Your browser does not support the video tag.
</video> 

</body>
</html>