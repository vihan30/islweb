
<?php include('server.php') ?>
<?php require('connect.php') ?>
<?php include('PHPMailerAutoload.php') ?>
<?php


$name = $_SESSION['username'];
$select_query="SELECT * FROM db_user WHERE user_id = '$name'";
$select_query_result = mysqli_query($db,$select_query) or die(mysqli_error($db));
$results = mysqli_fetch_assoc($select_query_result);
$var1 = $results['prefix'] ;
$var2 = $results['id'];
$arr = array($var1,$var2);
$App_id = implode($arr);
					//sending mail
					$sql = "SELECT * FROM users WHERE username = '$name'";
                    $res = mysqli_query($db, $sql);
	                $r = mysqli_fetch_assoc($res);
                    $email = $r['email'];		
                     $to = $email;
                     $subject = "Application Submitted";

                     $message =  "Dear ".$name.". "."Your Application has been submitted we will inform you as soon as it will get approval.Your Application Id is ".$App_id.". "."Do not disclose this information to anyone.";

                     $headers =  'MIME-Version: 1.0' . "\r\n"; 
                     $headers .= "From: mailserver3011@gmail.com . \r\n";
                     $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
                     mail($to, $subject, $message, $headers);
                     //sending application to admin 
                     $query = "SELECT * FROM admin WHERE id = 1";
                     $res_A = mysqli_query($db, $query);
                     $r_A = mysqli_fetch_assoc($res_A);
                     $email_A = $r_A['email'];   
                     $admin = $r_A['name']; 
                     $to_A = $email_A;
                     $subject_A = "Application Recieved";

                     $message_A =  "Dear".$admin."You have recieved an Application request For ISL Database.For more information visit: <a href ='http://localhost/isl/admin/admin.php'>ISL Admin Panel</a>";

                     $headers_A =  'MIME-Version: 1.0' . "\r\n"; 
                     $headers_A .= "From: mailserver3011@gmail.com . \r\n";
                     $headers_A .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 

                        mail($to_A, $subject_A, $message_A, $headers_A);
                    

?>