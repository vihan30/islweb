<?php require('connect.php') ?>
<?php
session_start();

$username = "";
$email    = "";
$errors = array(); 
 
 //apply data
$user_id = "" ;
$name = "" ;
$bio = "";
$purpose    = "";



if (isset($_POST['reg_user'])) {
  // inputs
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($db, $_POST['password_2']);

  // form validation
  if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }
  if ($password_1 != $password_2) {
	array_push($errors, "The two passwords do not match");
  }

  
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { 
    if ($user['username'] === $username) {
      array_push($errors, "Username already exists");
    }

    if ($user['email'] === $email) {
      array_push($errors, "email already exists");
    }
  }

  // registration
  if (count($errors) == 0) {
  	$password = md5($password_1);

  	$query = "INSERT INTO users (username, email, password) 
  			  VALUES('$username', '$email', '$password')";
  	mysqli_query($db, $query);
  	$_SESSION['username'] = $username;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: index.php');
  }
}





// LOGIN USER
if (isset($_POST['login_user'])) {
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($username)) {
  	array_push($errors, "Username is required");
  }
  if (empty($password)) {
  	array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
  	$password = md5($password);
  	$query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
  	$results = mysqli_query($db, $query);
  	if (mysqli_num_rows($results) == 1) {
  	  $_SESSION['username'] = $username;
  	  $_SESSION['success'] = "You are now logged in";
  	  header('location: index.php');
  	}else {
  		array_push($errors, "Wrong username/password combination");
  	}
  }
}

//APPly
if (isset($_POST['apply_user'])) {
  //inputs
  $user_id = mysqli_real_escape_string($db,$_POST['user_id']);
  $name = mysqli_real_escape_string($db,$_POST['name']);
  $bio = mysqli_real_escape_string($db, $_POST['bio']);
  $purpose = mysqli_real_escape_string($db, $_POST['purpose']);
  
  //prefix generator
   $generator = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $n = 3 ;  
    $prefix = ""; 
    for ($i = 1; $i <= $n; $i++) { 
        $prefix .= substr($generator, (rand()%(strlen($generator))), 1); 
    } 
   
  $permission = "0";
   //validation
   if (empty($name)) { array_push($errors, "required"); }
  if (empty($bio)) { array_push($errors, "required"); }
  if (empty($purpose)) { array_push($errors, "required"); }


  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM db_user WHERE user_id='$user_id' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { 
    if ($user['user_id'] === $user_id) {
      array_push($errors, "<script> alert('You have applied before'); </script>");
    }
  }

  //input
  if (count($errors) == 0) {

    $query = "INSERT INTO db_user (prefix, user_id,name,bio, purpose, permission) 
          VALUES('$prefix','$user_id','$name', '$bio', '$purpose','$permission')";
    $querysubmit= mysqli_query($db, $query) or die(mysqli_error($db));
    header('location:RequestSubmit.php');
  }
}






?>