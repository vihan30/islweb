<?php include('server.php') ?>
<?php require('connect.php') ?>
<?php 


if(isset($_POST) & !empty($_POST))
{
	  //checking email is registered or not
	  $email = mysqli_real_escape_string($db, $_POST['email']);
	  $sql = "SELECT * FROM users WHERE email = '$email'";
      $res = mysqli_query($db, $sql);
	  $r = mysqli_fetch_assoc($res);
      $email = $r['email'];
      if (empty($email)) { echo "Email not found"; }
  
      //generating token
      if ($email) {
        $username = $r['username'];
        $token = rand(999, 99999);
        $token_hash = md5($token);
        $user_check_query = "SELECT * FROM recovery_keys WHERE userID = '$username' LIMIT 1";
        $result1 = mysqli_query($db, $user_check_query);
        $user = mysqli_fetch_assoc($result1);
        $created=date('Y-m-d H:i:s', time());
            if ($user) { 
                         $usql = "UPDATE recovery_keys SET token='$token_hash',created = '$created' WHERE userID='$username'";
                         $querysubmit= mysqli_query($db,$usql) or die(mysqli_error($db));

                        }
                 else {
                        $query = "INSERT INTO recovery_keys(userID,token,created) VALUES('$username','$token_hash','$created')";
  	                     $querysubmit= mysqli_query($db,$query) or die(mysqli_error($db));
                      }
                   
  	   

  	   //sending token
                 
                     $to = $email;
                     $subject = "Your token";

                     $message = $username." Please use this token to reset password " . $token;
                     $headers =  'MIME-Version: 1.0' . "\r\n"; 
                     $headers .= "From: mailserver3011@gmail.com . \r\n";
                     $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
                        if(mail($to, $subject, $message, $headers)) {
                                  echo "<script>
                                       alert('Your OTP has been sent to your email_ID please check spam box too');
                                       window.location.href='resetpassword.php';
                                        </script>";
                                                                   }  else{
                             echo "<script>
                                       alert('Failed to Recover , try again');
                                        window.location.href='forgotpassword.php';
                                   </script>";
                                                                        }
                  }
                
            



}
            




?>