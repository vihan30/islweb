<?php include 'server.php'; ?>
<?php
if (isset($_SESSION['username'])) {
    include 'loginnavbar.php';
}
else {
    include 'navbar.php';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="index.css">
    <link href="https://fonts.googleapis.com/css?family=Lora|Oswald&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body>
    

          <!-- upper-section -->
    <div class="upper-section">
        <div class="container" >
            <div class= "heading" style="margin-top: 3.5rem;"> Indian Sign Language (ISL) </div>
            <img class="front-image" src="home.jpg" alt="Image" > 
            <p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  India has a large population of speech and hearing impaired people. Statistically, Census 2011, 
                (Ministry of Social Welfare, Government of India) states that 7.5% of India's population is "speech impaired" while 18.9% is "hearing impaired". There are some common terms being used in the website for the better information sharing, such as the word "deaf" refers to the speech and hearing impaired using sign language. The deaf community uses sign language as one of the communication media. As in the verbal communication varies in terms of local accents and regional language in sign laguage too.  Globaly, various countries have their own sign language, e.g. the Australian Sign Language (Auslan), the American Sign Language (ASL), the French Sign Language (FSL), the British Sign Language (BSL) and the Indian Sign Language (ISL).<a href="moreNew.html">Learn More...</a>
            </p>        
        </div>
    </div> 

            <!-- mid-section -->
    <div class="mid-section">
        <div class="container">
            <div class="heading">Vision</div>
            <p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
        </div>
    </div>

    <div class="mid-section">
        <div class="container">
            <div class="heading">About Researcher</div>
            <p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
        </div>
    </div>

  

  <?php
include 'ISLfooter.php';
?>


</body>
</html>
