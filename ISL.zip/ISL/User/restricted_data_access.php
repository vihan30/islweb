<!DOCTYPE html>
<html>
<head>
	<title></title>
<?php include('server.php') ?>
<?php
 if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }
?>
<?php 
include 'connect.php';
//restricting user to access database...
$sql = "SELECT * from db_user where permission='0' and user_id='".$_SESSION['username']."'   LIMIT 1";
$result = mysqli_query($db, $sql);
$user = mysqli_fetch_assoc($result);
if ($user){
   echo "<script>
                alert('You have applied before.We are working on your application.');
                window.location.href='index.php';
          </script>";
      }
$query = "SELECT * from db_user where permission='2' and user_id='".$_SESSION['username']."'   LIMIT 1";
$res = mysqli_query($db, $query);
$rejected_user = mysqli_fetch_assoc($res);
if ($rejected_user){
   echo "<script>
                alert('We are sorry your application is rejected.');
                window.location.href='index.php';
          </script>";
}
?>
</head>
<body>
Hey you fool !
</body>
</html>
